# Prácticas Profesionalizantes

Sitio para llevar el control de las prácticas profesionalizantes de los alumnos:
horas por sector, fechas de práctica (con búsqueda), informes presentados,
búsqueda de archivos en una carpeta de Drive, faltas, asistencia y notificaciones
por mail. Pensado para 3 usuarios (administración/tutores) y hasta ~50 alumnos.

**Stack:** HTML/CSS/JS puro (sin build), Firebase Auth + Firestore, Google
Identity Services para Drive, EmailJS para los mails. Todo se sirve como
archivos estáticos, ideal para GitHub Pages.

## 1. Crear el proyecto de Firebase (gratis, sin tarjeta)

1. Entrá a https://console.firebase.google.com/ y creá un proyecto nuevo.
2. En **Authentication → Sign-in method**, habilitá el proveedor **Email/contraseña**.
3. En **Authentication → Users**, creá los 3 usuarios (email + contraseña) que van a usar el sistema.
   Copiá el **UID** de cada uno (lo vas a necesitar en el paso 5).
4. En **Firestore Database**, creá la base de datos (modo producción).
5. En **Firestore → Reglas**, pegá el contenido del archivo `firestore.rules` de este proyecto y publicá.
6. En **Configuración del proyecto → Tus apps**, agregá una app web y copiá el
   objeto de configuración (`apiKey`, `authDomain`, etc.) al archivo `js/firebase-config.js`.

## 2. Cargar los perfiles de usuario (nombre + rol)

Los 3 usuarios ya existen en Firebase Auth (paso 1.3), pero la app necesita
saber su nombre y si son "admin" o "tutor". Para el primer usuario (el admin),
hay que cargarlo a mano una vez desde la consola de Firestore, porque hasta
que exista un admin nadie puede usar la pantalla de "Usuarios" del sitio:

1. En **Firestore Database → Datos**, creá manualmente una colección `usuarios`.
2. Agregá un documento cuyo **ID sea el UID** de tu primer usuario (el admin), con estos campos:
   - `nombre` (string): tu nombre
   - `email` (string): el mismo email de esa cuenta
   - `rol` (string): `admin`
3. Iniciá sesión en el sitio con ese usuario. Desde la pantalla **Usuarios**
   ya vas a poder cargar los otros 2 (pegando su UID, que sacás de Authentication → Users).

## 3. Google Drive (búsqueda de archivos)

1. Andá a https://console.cloud.google.com/ y creá (o reusá) un proyecto.
2. **APIs y servicios → Biblioteca** → habilitá **Google Drive API**.
3. **APIs y servicios → Pantalla de consentimiento OAuth**: configurala como
   "Externa" (o "Interna" si usás Google Workspace), agregando los 3 emails
   como usuarios de prueba.
4. **APIs y servicios → Credenciales → Crear credenciales → ID de cliente de OAuth**,
   tipo **Aplicación web**. En "Orígenes de JavaScript autorizados" agregá la
   URL donde vas a publicar el sitio (por ejemplo `https://tuusuario.github.io`).
5. Copiá el **Client ID** generado a `js/firebase-config.js` (`googleDriveConfig.clientId`).
6. Compartí la carpeta de Drive que querés que se pueda buscar con los emails
   de los 3 usuarios (o dejala accesible para cualquiera con el link, según prefieras).
7. Copiá el **ID de la carpeta** (está en la URL de Drive, después de `/folders/`)
   a `googleDriveConfig.folderId`.

Nota: como el sitio es estático, no hay forma de guardar una credencial de
Drive "compartida" de forma segura. Por eso cada usuario autoriza el acceso
de solo lectura desde su propia cuenta de Google la primera vez que usa esa
sección (botón "Conectar con Google Drive").

## 4. EmailJS (notificaciones por mail)

1. Creá una cuenta gratis en https://www.emailjs.com/ (200 mails/mes gratis).
2. Conectá tu servicio de mail (Gmail u otro) en **Email Services** y copiá el **Service ID**.
3. Creá una plantilla en **Email Templates** con estas variables:
   `{{to_email}}`, `{{to_name}}`, `{{lugar}}`, `{{fecha}}`, `{{horario}}`, `{{tutor}}`, `{{contacto}}`.
4. Copiá el **Template ID** y tu **Public Key** (en Account → General).
5. Completá los tres valores en `js/firebase-config.js` (`emailjsConfig`).

## 5. Publicar en GitHub Pages

1. Subí todo este proyecto a un repositorio de GitHub.
2. En el repo: **Settings → Pages → Source**, elegí la rama `main` y la carpeta `/ (root)`.
3. Esperá un minuto y el sitio va a quedar publicado en
   `https://tuusuario.github.io/nombre-del-repo/`.
4. Volvé al paso 3.4 (Google Cloud) y al 6 (Firebase Authentication, si pide
   dominios autorizados) y agregá esa URL como origen permitido.

## Probarlo en tu computadora antes de subirlo

No hace falta ningún servidor especial, pero los módulos de JavaScript (`type="module"`)
no funcionan si abrís el `index.html` directo con doble click. Corré un
servidor simple desde la carpeta del proyecto, por ejemplo:

```bash
python3 -m http.server 8000
```

y abrí `http://localhost:8000` en el navegador.

## Estructura del proyecto

```
index.html            La app completa (todas las secciones)
css/style.css         Estilos
js/firebase-config.js  Tus claves de Firebase / Drive / EmailJS (completar)
js/app.js              Lógica principal: login, navegación, CRUD de Firestore
js/drive.js             Búsqueda en Google Drive (OAuth de navegador)
firestore.rules        Reglas de seguridad para pegar en Firebase Console
```

## Qué ampliaría primero

1. **Export a Excel/PDF** de horas por alumno y por sector (útil para
   entregar constancias o reportes a la institución).
2. **Notificaciones automáticas programadas** (hoy el envío es manual con un
   botón): se podría sumar Google Apps Script como disparador diario gratuito
   que llame a EmailJS o a un webhook, sin necesitar un servidor propio.
3. **Registro de asistencia con QR o geolocalización** para que el alumno
   marque entrada/salida desde su celular en el lugar de práctica.
4. **Historial de cambios** (quién editó qué y cuándo) en Firestore, útil si
   hay auditorías.
5. **Recordatorio automático de faltas** cuando un alumno acumula más de N
   inasistencias no justificadas.
