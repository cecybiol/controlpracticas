// Reemplazá estos valores por los de TU proyecto de Firebase.
// Se obtienen en: Firebase Console -> Configuración del proyecto -> Tus apps -> Config
// Estas claves son públicas por diseño (no son secretas); la seguridad real
// la dan las Reglas de Firestore (ver firestore.rules) y el login de Auth.
export const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "tu-proyecto.firebaseapp.com",
  projectId: "tu-proyecto",
  storageBucket: "tu-proyecto.appspot.com",
  messagingSenderId: "000000000000",
  appId: "1:000000000000:web:xxxxxxxxxxxxxxxx",
};

// --- Google Drive (búsqueda de archivos) ---
// Client ID de OAuth (tipo "Aplicación web") creado en Google Cloud Console.
// Ver README para el paso a paso.
export const googleDriveConfig = {
  clientId: "TU_CLIENT_ID.apps.googleusercontent.com",
  folderId: "ID_DE_LA_CARPETA_DE_DRIVE",
};

// --- EmailJS (envío de notificaciones) ---
// Se obtienen en https://www.emailjs.com/ (plan gratis: 200 mails/mes)
export const emailjsConfig = {
  publicKey: "TU_PUBLIC_KEY",
  serviceId: "TU_SERVICE_ID",
  templateId: "TU_TEMPLATE_ID",
};
