import { firebaseConfig, emailjsConfig } from "./firebase-config.js";
import { initApp as initDrive, buscarEnDrive } from "./drive.js";

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import {
  getFirestore, collection, doc, addDoc, updateDoc, deleteDoc,
  getDocs, getDoc, query, orderBy, setDoc,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

if (window.emailjs && emailjsConfig.publicKey !== "TU_PUBLIC_KEY") {
  window.emailjs.init({ publicKey: emailjsConfig.publicKey });
}

let usuarioActual = null; // { uid, nombre, rol, email }
let cacheAlumnos = [];    // se recarga al entrar a cada vista que la necesita

// ---------------------------------------------------------- helpers UI ---
function mostrarAlerta(mensaje, tipo = "success") {
  const cont = document.getElementById("alertas");
  const div = document.createElement("div");
  div.className = `alert alert-${tipo} alert-dismissible fade show`;
  div.innerHTML = `${mensaje}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
  cont.appendChild(div);
  setTimeout(() => div.remove(), 6000);
}

function fmtFecha(iso) {
  if (!iso) return "-";
  const [y, m, d] = iso.split("-");
  return `${d}/${m}/${y}`;
}

function abrirModal(id) {
  new bootstrap.Modal(document.getElementById(id)).show();
}
function cerrarModal(id) {
  bootstrap.Modal.getInstance(document.getElementById(id))?.hide();
}

function mostrarVista(nombre) {
  document.querySelectorAll(".vista").forEach(v => v.classList.remove("activa"));
  document.getElementById(`vista-${nombre}`).classList.add("activa");
  document.querySelectorAll("[data-view]").forEach(a => a.classList.remove("active"));
  document.querySelector(`[data-view="${nombre}"]`)?.classList.add("active");
  cargarVista(nombre);
}

function cargarVista(nombre) {
  const cargadores = {
    dashboard: cargarDashboard,
    alumnos: cargarAlumnos,
    practicas: () => cargarPracticas(),
    informes: cargarInformes,
    faltas: cargarFaltas,
    asistencia: cargarAsistencia,
    notificaciones: cargarNotificaciones,
    usuarios: cargarUsuarios,
    drive: () => {},
  };
  cargadores[nombre]?.();
}

document.querySelectorAll("[data-view]").forEach(a => {
  a.addEventListener("click", (e) => {
    e.preventDefault();
    mostrarVista(a.dataset.view);
  });
});

// ------------------------------------------------------------------ AUTH -
document.getElementById("form-login").addEventListener("submit", async (e) => {
  e.preventDefault();
  const email = document.getElementById("login-email").value.trim();
  const password = document.getElementById("login-password").value;
  const errBox = document.getElementById("login-error");
  errBox.classList.add("d-none");
  try {
    await signInWithEmailAndPassword(auth, email, password);
  } catch (err) {
    errBox.textContent = "No se pudo iniciar sesión. Revisá el email y la contraseña.";
    errBox.classList.remove("d-none");
  }
});

document.getElementById("btn-logout").addEventListener("click", () => signOut(auth));

onAuthStateChanged(auth, async (user) => {
  if (user) {
    let perfil = { nombre: user.email, rol: "tutor" };
    try {
      const snap = await getDoc(doc(db, "usuarios", user.uid));
      if (snap.exists()) perfil = snap.data();
    } catch (e) { /* si todavía no existe el doc de perfil, seguimos con default */ }

    usuarioActual = { uid: user.uid, email: user.email, ...perfil };
    document.getElementById("usuario-actual").textContent = `${usuarioActual.nombre} (${usuarioActual.rol})`;
    document.querySelectorAll(".admin-only").forEach(el => {
      el.classList.toggle("d-none", usuarioActual.rol !== "admin");
    });

    document.getElementById("login-view").classList.add("d-none");
    document.getElementById("app-shell").classList.remove("d-none");
    mostrarVista("dashboard");
  } else {
    usuarioActual = null;
    document.getElementById("app-shell").classList.add("d-none");
    document.getElementById("login-view").classList.remove("d-none");
  }
});

// --------------------------------------------------------------- ALUMNOS -
async function obtenerAlumnos(forzar = false) {
  if (cacheAlumnos.length && !forzar) return cacheAlumnos;
  const snap = await getDocs(query(collection(db, "alumnos"), orderBy("apellido")));
  cacheAlumnos = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  return cacheAlumnos;
}

function nombreCompleto(a) {
  return `${a.apellido}, ${a.nombre}`;
}

async function llenarSelectAlumnos(selectEl, seleccionadoId = null) {
  const alumnos = await obtenerAlumnos();
  selectEl.innerHTML = alumnos.map(a =>
    `<option value="${a.id}" ${a.id === seleccionadoId ? "selected" : ""}>${nombreCompleto(a)} (${a.legajo})</option>`
  ).join("");
}

async function cargarAlumnos() {
  const alumnos = await obtenerAlumnos(true);
  document.getElementById("tabla-alumnos").innerHTML = alumnos.map(a => `
    <tr>
      <td>${a.legajo}</td><td>${nombreCompleto(a)}</td><td>${a.sector || ""}</td><td>${a.email || ""}</td>
      <td><button class="btn btn-sm btn-outline-secondary" onclick="window.editarAlumno('${a.id}')">Editar</button></td>
    </tr>`).join("") || `<tr><td colspan="5" class="text-muted">No hay alumnos cargados.</td></tr>`;
}

document.getElementById("btn-nuevo-alumno").addEventListener("click", () => {
  document.getElementById("form-alumno").reset();
  document.getElementById("alumno-id").value = "";
  abrirModal("modal-alumno");
});

window.editarAlumno = async (id) => {
  const alumnos = await obtenerAlumnos();
  const a = alumnos.find(x => x.id === id);
  document.getElementById("alumno-id").value = a.id;
  document.getElementById("alumno-legajo").value = a.legajo;
  document.getElementById("alumno-nombre").value = a.nombre;
  document.getElementById("alumno-apellido").value = a.apellido;
  document.getElementById("alumno-email").value = a.email || "";
  document.getElementById("alumno-sector").value = a.sector || "";
  abrirModal("modal-alumno");
};

document.getElementById("form-alumno").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("alumno-id").value;
  const datos = {
    legajo: document.getElementById("alumno-legajo").value.trim(),
    nombre: document.getElementById("alumno-nombre").value.trim(),
    apellido: document.getElementById("alumno-apellido").value.trim(),
    email: document.getElementById("alumno-email").value.trim(),
    sector: document.getElementById("alumno-sector").value.trim(),
  };
  if (id) {
    await updateDoc(doc(db, "alumnos", id), datos);
  } else {
    await addDoc(collection(db, "alumnos"), datos);
  }
  cerrarModal("modal-alumno");
  mostrarAlerta("Alumno guardado.");
  cargarAlumnos();
});

// ------------------------------------------------------------- PRACTICAS -
async function obtenerPracticas() {
  const alumnos = await obtenerAlumnos();
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));
  const snap = await getDocs(query(collection(db, "practicas"), orderBy("fecha", "desc")));
  return snap.docs.map(d => ({ id: d.id, ...d.data(), alumno: mapaAlumnos[d.data().alumnoId] }));
}

async function cargarPracticas() {
  let practicas = await obtenerPracticas();

  const fAlumno = document.getElementById("f-alumno").value.trim().toLowerCase();
  const fLugar = document.getElementById("f-lugar").value.trim().toLowerCase();
  const fTutor = document.getElementById("f-tutor").value.trim().toLowerCase();
  const fSector = document.getElementById("f-sector").value.trim().toLowerCase();
  const fDesde = document.getElementById("f-desde").value;
  const fHasta = document.getElementById("f-hasta").value;

  practicas = practicas.filter(p => {
    if (!p.alumno) return false;
    if (fAlumno && !(`${p.alumno.nombre} ${p.alumno.apellido} ${p.alumno.legajo}`.toLowerCase().includes(fAlumno))) return false;
    if (fLugar && !p.lugar?.toLowerCase().includes(fLugar)) return false;
    if (fTutor && !p.tutorResponsable?.toLowerCase().includes(fTutor)) return false;
    if (fSector && !p.sector?.toLowerCase().includes(fSector)) return false;
    if (fDesde && p.fecha < fDesde) return false;
    if (fHasta && p.fecha > fHasta) return false;
    return true;
  });

  document.getElementById("tabla-practicas").innerHTML = practicas.map(p => `
    <tr>
      <td>${fmtFecha(p.fecha)}</td><td>${p.alumno ? nombreCompleto(p.alumno) : "-"}</td>
      <td>${p.lugar}</td><td>${p.sector || ""}</td><td>${p.horaInicio || ""} - ${p.horaFin || ""}</td>
      <td>${p.horasTotales}</td><td>${p.tutorResponsable || ""}</td><td>${p.contacto || ""}</td>
      <td><button class="btn btn-sm btn-outline-secondary" onclick="window.editarPractica('${p.id}')">Editar</button></td>
    </tr>`).join("") || `<tr><td colspan="9" class="text-muted">No se encontraron prácticas.</td></tr>`;
}

document.getElementById("btn-filtrar-practicas").addEventListener("click", cargarPracticas);
document.getElementById("btn-limpiar-practicas").addEventListener("click", () => {
  ["f-alumno", "f-lugar", "f-tutor", "f-sector", "f-desde", "f-hasta"].forEach(id => document.getElementById(id).value = "");
  cargarPracticas();
});

document.getElementById("btn-nueva-practica").addEventListener("click", async () => {
  document.getElementById("form-practica").reset();
  document.getElementById("practica-id").value = "";
  await llenarSelectAlumnos(document.getElementById("practica-alumno"));
  abrirModal("modal-practica");
});

window.editarPractica = async (id) => {
  const practicas = await obtenerPracticas();
  const p = practicas.find(x => x.id === id);
  document.getElementById("practica-id").value = p.id;
  await llenarSelectAlumnos(document.getElementById("practica-alumno"), p.alumnoId);
  document.getElementById("practica-lugar").value = p.lugar;
  document.getElementById("practica-sector").value = p.sector || "";
  document.getElementById("practica-fecha").value = p.fecha;
  document.getElementById("practica-inicio").value = p.horaInicio || "";
  document.getElementById("practica-fin").value = p.horaFin || "";
  document.getElementById("practica-horas").value = p.horasTotales || 0;
  document.getElementById("practica-tutor").value = p.tutorResponsable || "";
  document.getElementById("practica-contacto").value = p.contacto || "";
  document.getElementById("practica-notas").value = p.notas || "";
  abrirModal("modal-practica");
};

document.getElementById("form-practica").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = document.getElementById("practica-id").value;
  const datos = {
    alumnoId: document.getElementById("practica-alumno").value,
    lugar: document.getElementById("practica-lugar").value.trim(),
    sector: document.getElementById("practica-sector").value.trim(),
    fecha: document.getElementById("practica-fecha").value,
    horaInicio: document.getElementById("practica-inicio").value,
    horaFin: document.getElementById("practica-fin").value,
    horasTotales: parseFloat(document.getElementById("practica-horas").value || 0),
    tutorResponsable: document.getElementById("practica-tutor").value.trim(),
    contacto: document.getElementById("practica-contacto").value.trim(),
    notas: document.getElementById("practica-notas").value.trim(),
  };
  if (id) {
    await updateDoc(doc(db, "practicas", id), datos);
  } else {
    await addDoc(collection(db, "practicas"), datos);
  }
  cerrarModal("modal-practica");
  mostrarAlerta("Fecha de práctica guardada.");
  cargarPracticas();
});

// --------------------------------------------------------------- INFORMES
async function cargarInformes() {
  const alumnos = await obtenerAlumnos();
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));
  const snap = await getDocs(query(collection(db, "informes"), orderBy("fechaPresentacion", "desc")));
  const informes = snap.docs.map(d => ({ id: d.id, ...d.data() }));

  document.getElementById("tabla-informes").innerHTML = informes.map(i => `
    <tr>
      <td>${mapaAlumnos[i.alumnoId] ? nombreCompleto(mapaAlumnos[i.alumnoId]) : "-"}</td>
      <td>${i.titulo}</td><td>${fmtFecha(i.fechaPresentacion)}</td>
      <td><span class="badge badge-estado-${i.estado}">${i.estado}</span></td>
      <td>${i.enlaceDrive ? `<a href="${i.enlaceDrive}" target="_blank">Ver archivo</a>` : ""}</td>
    </tr>`).join("") || `<tr><td colspan="5" class="text-muted">No hay informes registrados.</td></tr>`;
}

document.getElementById("btn-nuevo-informe").addEventListener("click", async () => {
  document.getElementById("form-informe").reset();
  await llenarSelectAlumnos(document.getElementById("informe-alumno"));
  abrirModal("modal-informe");
});

document.getElementById("form-informe").addEventListener("submit", async (e) => {
  e.preventDefault();
  const datos = {
    alumnoId: document.getElementById("informe-alumno").value,
    titulo: document.getElementById("informe-titulo").value.trim(),
    fechaPresentacion: document.getElementById("informe-fecha").value || new Date().toISOString().slice(0, 10),
    estado: document.getElementById("informe-estado").value,
    enlaceDrive: document.getElementById("informe-enlace").value.trim(),
    observaciones: document.getElementById("informe-obs").value.trim(),
  };
  await addDoc(collection(db, "informes"), datos);
  cerrarModal("modal-informe");
  mostrarAlerta("Informe registrado.");
  cargarInformes();
});

// ------------------------------------------------------------------ DRIVE
document.getElementById("btn-drive-login").addEventListener("click", () => initDrive());
document.getElementById("form-drive-buscar").addEventListener("submit", async (e) => {
  e.preventDefault();
  const query_ = document.getElementById("drive-query").value.trim();
  const estado = document.getElementById("drive-estado");
  estado.textContent = "Buscando...";
  try {
    const archivos = await buscarEnDrive(query_);
    estado.textContent = archivos.length ? "" : "Sin resultados.";
    document.getElementById("tabla-drive").innerHTML = archivos.map(f => `
      <tr>
        <td>${f.name}</td><td>${f.mimeType}</td><td>${new Date(f.modifiedTime).toLocaleString()}</td>
        <td><a href="${f.webViewLink}" target="_blank" class="btn btn-sm btn-outline-secondary">Abrir</a></td>
      </tr>`).join("");
  } catch (err) {
    estado.textContent = "Necesitás conectar con Google Drive primero (botón de arriba).";
  }
});

// --------------------------------------------------------------- FALTAS -
async function cargarFaltas() {
  const alumnos = await obtenerAlumnos();
  const selFiltro = document.getElementById("falta-filtro-alumno");
  if (selFiltro.options.length <= 1) {
    selFiltro.innerHTML += alumnos.map(a => `<option value="${a.id}">${nombreCompleto(a)}</option>`).join("");
  }
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));
  const snap = await getDocs(query(collection(db, "faltas"), orderBy("fecha", "desc")));
  let faltas = snap.docs.map(d => ({ id: d.id, ...d.data() }));

  const filtroId = selFiltro.value;
  if (filtroId) faltas = faltas.filter(f => f.alumnoId === filtroId);

  document.getElementById("tabla-faltas").innerHTML = faltas.map(f => `
    <tr>
      <td>${fmtFecha(f.fecha)}</td><td>${mapaAlumnos[f.alumnoId] ? nombreCompleto(mapaAlumnos[f.alumnoId]) : "-"}</td>
      <td>${f.justificada ? "Sí" : "No"}</td><td>${f.motivo || ""}</td>
    </tr>`).join("") || `<tr><td colspan="4" class="text-muted">No hay faltas registradas.</td></tr>`;
}

document.getElementById("falta-filtro-alumno").addEventListener("change", cargarFaltas);
document.getElementById("btn-nueva-falta").addEventListener("click", async () => {
  document.getElementById("form-falta").reset();
  await llenarSelectAlumnos(document.getElementById("falta-alumno"));
  abrirModal("modal-falta");
});

document.getElementById("form-falta").addEventListener("submit", async (e) => {
  e.preventDefault();
  await addDoc(collection(db, "faltas"), {
    alumnoId: document.getElementById("falta-alumno").value,
    fecha: document.getElementById("falta-fecha").value,
    justificada: document.getElementById("falta-justificada").checked,
    motivo: document.getElementById("falta-motivo").value.trim(),
  });
  cerrarModal("modal-falta");
  mostrarAlerta("Falta registrada.");
  cargarFaltas();
});

// ---------------------------------------------------------- ASISTENCIA --
async function cargarAsistencia() {
  const alumnos = await obtenerAlumnos();
  const selForm = document.getElementById("asist-alumno");
  const selFiltro = document.getElementById("asist-filtro-alumno");
  if (selForm.options.length === 0) selForm.innerHTML = alumnos.map(a => `<option value="${a.id}">${nombreCompleto(a)}</option>`).join("");
  if (selFiltro.options.length <= 1) selFiltro.innerHTML += alumnos.map(a => `<option value="${a.id}">${nombreCompleto(a)}</option>`).join("");

  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));
  const snap = await getDocs(query(collection(db, "asistencias"), orderBy("fecha", "desc")));
  let registros = snap.docs.map(d => ({ id: d.id, ...d.data() }));

  const filtroId = selFiltro.value;
  if (filtroId) registros = registros.filter(r => r.alumnoId === filtroId);
  registros = registros.slice(0, 100);

  document.getElementById("tabla-asistencia").innerHTML = registros.map(r => `
    <tr>
      <td>${fmtFecha(r.fecha)}</td><td>${mapaAlumnos[r.alumnoId] ? nombreCompleto(mapaAlumnos[r.alumnoId]) : "-"}</td>
      <td>${r.presente ? "Sí" : "No"}</td><td>${r.horaEntrada || ""}</td><td>${r.horaSalida || ""}</td><td>${r.observaciones || ""}</td>
    </tr>`).join("") || `<tr><td colspan="6" class="text-muted">No hay registros de asistencia.</td></tr>`;
}

document.getElementById("asist-filtro-alumno").addEventListener("change", cargarAsistencia);
document.getElementById("form-asistencia").addEventListener("submit", async (e) => {
  e.preventDefault();
  await addDoc(collection(db, "asistencias"), {
    alumnoId: document.getElementById("asist-alumno").value,
    fecha: document.getElementById("asist-fecha").value,
    presente: document.getElementById("asist-presente").checked,
    horaEntrada: document.getElementById("asist-entrada").value,
    horaSalida: document.getElementById("asist-salida").value,
    observaciones: document.getElementById("asist-obs").value.trim(),
  });
  document.getElementById("form-asistencia").reset();
  document.getElementById("asist-presente").checked = true;
  mostrarAlerta("Asistencia registrada.");
  cargarAsistencia();
});

// ------------------------------------------------------- NOTIFICACIONES -
async function cargarNotificaciones() {
  const dias = parseInt(document.getElementById("notif-dias").value || "3", 10);
  const alumnos = await obtenerAlumnos();
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));

  const hoy = new Date().toISOString().slice(0, 10);
  const limite = new Date(Date.now() + dias * 86400000).toISOString().slice(0, 10);

  const snap = await getDocs(collection(db, "practicas"));
  const proximas = snap.docs
    .map(d => ({ id: d.id, ...d.data() }))
    .filter(p => p.fecha >= hoy && p.fecha <= limite)
    .sort((a, b) => a.fecha.localeCompare(b.fecha));

  document.getElementById("tabla-notif-proximas").innerHTML = proximas.map(p => `
    <tr>
      <td>${fmtFecha(p.fecha)}</td>
      <td>${mapaAlumnos[p.alumnoId] ? nombreCompleto(mapaAlumnos[p.alumnoId]) : "-"}</td>
      <td>${mapaAlumnos[p.alumnoId]?.email || "(sin email)"}</td>
      <td>${p.lugar}</td>
    </tr>`).join("") || `<tr><td colspan="4" class="text-muted">No hay prácticas próximas en ese rango.</td></tr>`;

  document.getElementById("btn-notif-enviar").dataset.proximas = JSON.stringify(proximas);

  const histSnap = await getDocs(query(collection(db, "notificaciones_log"), orderBy("fechaEnvio", "desc")));
  const historial = histSnap.docs.map(d => d.data()).slice(0, 30);
  document.getElementById("tabla-notif-historial").innerHTML = historial.map(h => `
    <tr>
      <td>${new Date(h.fechaEnvio).toLocaleString()}</td>
      <td>${mapaAlumnos[h.alumnoId] ? nombreCompleto(mapaAlumnos[h.alumnoId]) : h.alumnoId}</td>
      <td><span class="badge bg-${h.estado === "enviado" ? "success" : "danger"}">${h.estado}</span></td>
      <td>${h.detalle || "-"}</td>
    </tr>`).join("") || `<tr><td colspan="4" class="text-muted">Sin envíos todavía.</td></tr>`;
}

document.getElementById("btn-notif-actualizar").addEventListener("click", cargarNotificaciones);

document.getElementById("btn-notif-enviar").addEventListener("click", async (e) => {
  const proximas = JSON.parse(e.target.dataset.proximas || "[]");
  const alumnos = await obtenerAlumnos();
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));

  if (!window.emailjs || emailjsConfig.publicKey === "TU_PUBLIC_KEY") {
    mostrarAlerta("Falta configurar EmailJS en firebase-config.js (ver README).", "warning");
    return;
  }

  let enviados = 0, errores = 0;
  for (const p of proximas) {
    const alumno = mapaAlumnos[p.alumnoId];
    let estado = "error", detalle = "Alumno sin email cargado";
    if (alumno?.email) {
      try {
        await window.emailjs.send(emailjsConfig.serviceId, emailjsConfig.templateId, {
          to_email: alumno.email,
          to_name: alumno.nombre,
          lugar: p.lugar,
          fecha: fmtFecha(p.fecha),
          horario: `${p.horaInicio || ""} - ${p.horaFin || ""}`,
          tutor: p.tutorResponsable || "",
          contacto: p.contacto || "",
        });
        estado = "enviado"; detalle = ""; enviados++;
      } catch (err) {
        detalle = "Error al enviar el mail"; errores++;
      }
    } else { errores++; }

    await addDoc(collection(db, "notificaciones_log"), {
      alumnoId: p.alumnoId, practicaId: p.id, tipo: "recordatorio_practica",
      estado, detalle, fechaEnvio: new Date().toISOString(),
    });
  }
  mostrarAlerta(`Notificaciones enviadas: ${enviados}. Errores: ${errores}.`, "info");
  cargarNotificaciones();
});

// ------------------------------------------------------------- USUARIOS -
async function cargarUsuarios() {
  const snap = await getDocs(collection(db, "usuarios"));
  const usuarios = snap.docs.map(d => ({ id: d.id, ...d.data() }));
  document.getElementById("usuarios-count").textContent = usuarios.length;
  document.getElementById("tabla-usuarios").innerHTML = usuarios.map(u => `
    <tr><td>${u.nombre}</td><td>${u.email}</td><td>${u.rol}</td></tr>
  `).join("") || `<tr><td colspan="3" class="text-muted">No hay perfiles cargados todavía.</td></tr>`;

  const formUsuario = document.getElementById("form-usuario");
  formUsuario.classList.toggle("d-none", usuarios.length >= 3 && !formUsuario.dataset.editando);
}

document.getElementById("form-usuario").addEventListener("submit", async (e) => {
  e.preventDefault();
  const snap = await getDocs(collection(db, "usuarios"));
  const uid = document.getElementById("usuario-uid").value.trim();
  const yaExiste = snap.docs.some(d => d.id === uid);
  if (snap.size >= 3 && !yaExiste) {
    mostrarAlerta("Ya hay 3 usuarios cargados (el máximo permitido).", "danger");
    return;
  }
  await setDoc(doc(db, "usuarios", uid), {
    nombre: document.getElementById("usuario-nombre").value.trim(),
    email: document.getElementById("usuario-email").value.trim(),
    rol: document.getElementById("usuario-rol").value,
  });
  document.getElementById("form-usuario").reset();
  mostrarAlerta("Usuario guardado.");
  cargarUsuarios();
});

// ------------------------------------------------------------ DASHBOARD -
async function cargarDashboard() {
  const alumnos = await obtenerAlumnos(true);
  const snap = await getDocs(collection(db, "practicas"));
  const practicas = snap.docs.map(d => d.data());

  const totalHoras = practicas.reduce((acc, p) => acc + (p.horasTotales || 0), 0);
  document.getElementById("stat-horas").textContent = totalHoras.toFixed(1);
  document.getElementById("stat-alumnos").textContent = alumnos.length;
  document.getElementById("stat-practicas").textContent = practicas.length;

  const porSector = {};
  practicas.forEach(p => {
    const s = p.sector || "Sin sector";
    porSector[s] = (porSector[s] || 0) + (p.horasTotales || 0);
  });
  document.getElementById("tabla-horas-sector").innerHTML = Object.entries(porSector)
    .map(([s, h]) => `<tr><td>${s}</td><td>${h.toFixed(1)}</td></tr>`).join("")
    || `<tr><td colspan="2" class="text-muted">Todavía no hay prácticas cargadas.</td></tr>`;

  const hoy = new Date().toISOString().slice(0, 10);
  const mapaAlumnos = Object.fromEntries(alumnos.map(a => [a.id, a]));
  const proximas = practicas
    .map((p, idx) => ({ ...p, id: snap.docs[idx].id }))
    .filter(p => p.fecha >= hoy)
    .sort((a, b) => a.fecha.localeCompare(b.fecha))
    .slice(0, 5);
  document.getElementById("tabla-proximas").innerHTML = proximas.map(p => `
    <tr><td>${fmtFecha(p.fecha)}</td><td>${mapaAlumnos[p.alumnoId] ? nombreCompleto(mapaAlumnos[p.alumnoId]) : "-"}</td><td>${p.lugar}</td></tr>
  `).join("") || `<tr><td colspan="3" class="text-muted">No hay prácticas próximas.</td></tr>`;
}
